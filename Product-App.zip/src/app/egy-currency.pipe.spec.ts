import { EgyCurrencyPipe } from './egy-currency.pipe';

describe('EgyCurrencyPipe', () => {
  it('create an instance', () => {
    const pipe = new EgyCurrencyPipe();
    expect(pipe).toBeTruthy();
  });
});
